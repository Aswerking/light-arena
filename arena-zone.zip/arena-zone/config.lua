Config = {}

-- ===== Main Arena Zone =====
-- Using center + radius (no PolyZone needed)
Config.ArenaCenter = vector3(459.0, -3091.0, 6.0)
Config.ArenaRadius = 35.0

-- ===== Respawn Settings =====
Config.DeathWaitTime = 5       -- Seconds to wait after death
Config.RespawnHealDelay = 3    -- Seconds after respawn to heal

-- ===== Respawn Points =====
Config.RespawnPoints = {
    vector4(469.91519, -3067.106, 6.0639781, 296.30136),
    vector4(459.71713, -3066.892, 7.0349307, 84.807998),
    vector4(448.02282, -3115.577, 6.070055, 77.068275),
    vector4(469.81942, -3115.581, 6.0716567, 227.60139),
}

-- ===== Weapon Shop NPC =====
Config.WeaponShop = {
    coords = vector4(449.36953, -3078.714, 6.0696339, 19.231742),
    pedModel = 's_m_y_ammucity_01',
    weapon = 'WEAPON_COMBATPISTOL',
    ammo = 100,
    label = 'Combat Pistol (Rubber)',
}

-- ===== Weapon Removal Zone (leaving this zone removes weapon) =====
-- Polygon points defining the weapon zone boundary
Config.WeaponZonePoints = {
    vector2(456.98, -3073.0),
    vector2(455.53, -3067.33),
    vector2(447.28, -3066.41),
    vector2(444.25, -3072.62),
    vector2(444.24, -3076.92),
    vector2(445.88, -3070.53),
}
Config.WeaponZoneMinZ = 4.0
Config.WeaponZoneMaxZ = 12.0

-- ===== Purchase Requirement =====
Config.RequiredEventStage = 2

-- ===== Hit & Death Sound Effects =====
-- Place sound files in html/sounds/ as .ogg
-- youcane.ogg  = First hit sound
-- focus.ogg    = Second hit and beyond
-- youkill.ogg  = Death sound (plays first)
-- noob.ogg     = Death sound (plays after youkill)
Config.SoundVolume = 0.8
