fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'light'
description 'Arena Zone - Auto Respawn, Rubber Bullet Weapon, Admin Shop'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/sounds/youcane.ogg',
    'html/sounds/focus.ogg',
    'html/sounds/youkill.ogg',
    'html/sounds/noob.ogg',
}

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}
