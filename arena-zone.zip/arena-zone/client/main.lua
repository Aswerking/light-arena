local QBCore = exports['qb-core']:GetCoreObject()

local isInArenaZone = false
local currentEventStage = 0
local hasArenaWeapon = false
local shopPed = nil
local isRespawning = false
local hitCount = 0 -- Hit counter for victim player

-- ===================================================================
-- Helper Functions
-- ===================================================================

local function LoadModel(model)
    local hash = type(model) == 'string' and GetHashKey(model) or model
    if not IsModelInCdimage(hash) then
        print('[Arena Zone] Model not in cdimage: ' .. tostring(model))
        return false
    end
    RequestModel(hash)
    local timeout = 0
    while not HasModelLoaded(hash) do
        Wait(50)
        timeout = timeout + 50
        if timeout > 10000 then
            print('[Arena Zone] Timeout loading model: ' .. tostring(model))
            return false
        end
    end
    return true
end

local function GetDistance(pos1, pos2)
    return #(vector3(pos1.x, pos1.y, pos1.z) - vector3(pos2.x, pos2.y, pos2.z))
end

local function IsPlayerInArena()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    return GetDistance(pos, Config.ArenaCenter) <= Config.ArenaRadius
end

local function IsPlayerInWeaponZone()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)

    -- Check height first
    if pos.z < Config.WeaponZoneMinZ or pos.z > Config.WeaponZoneMaxZ then
        return false
    end

    -- Ray Casting Algorithm (same as PolyZone method)
    local points = Config.WeaponZonePoints
    local n = #points
    local inside = false
    local j = n

    for i = 1, n do
        local xi, yi = points[i].x, points[i].y
        local xj, yj = points[j].x, points[j].y

        if ((yi > pos.y) ~= (yj > pos.y)) and (pos.x < (xj - xi) * (pos.y - yi) / (yj - yi) + xi) then
            inside = not inside
        end
        j = i
    end

    return inside
end

local function GetRandomRespawnPoint()
    return Config.RespawnPoints[math.random(1, #Config.RespawnPoints)]
end

-- ===================================================================
-- Sound System (NUI)
-- ===================================================================

local function PlayArenaSound(soundName, volume)
    SendNUIMessage({
        action = 'playSound',
        sound = soundName,
        volume = volume or 0.8,
    })
end

local function PlayDeathSounds(volume)
    SendNUIMessage({
        action = 'playDeathSounds',
        volume = volume or 0.8,
    })
end

-- ===================================================================
-- Hit Tracking System - Victim hears the sounds
-- ===================================================================

-- Victim hears sound when hit
RegisterNetEvent('arena:client:GotHit', function(hitNumber)
    if hitNumber == 1 then
        -- First hit = "You Cane"
        PlayArenaSound('youcane', 0.8)
    elseif hitNumber >= 2 then
        -- Second hit and beyond = "Focus"
        PlayArenaSound('focus', 0.8)
    end
end)

-- Victim hears sound when killed
RegisterNetEvent('arena:client:GotKilled', function()
    PlayDeathSounds(0.8)
end)

-- ===================================================================
-- Shooting Detection & Player Hit Tracking
-- ===================================================================

CreateThread(function()
    while true do
        local sleep = 100
        if isInArenaZone and hasArenaWeapon then
            sleep = 0
            local ped = PlayerPedId()

            if IsPedShooting(ped) then
                local _, targetEntity = GetEntityPlayerIsFreeAimingAt(PlayerId())
                if targetEntity and targetEntity ~= 0 and IsEntityAPed(targetEntity) and IsPedAPlayer(targetEntity) then
                    -- Get the player who got hit
                    local targetPlayer = NetworkGetPlayerIndexFromPed(targetEntity)
                    if targetPlayer and targetPlayer ~= -1 then
                        local targetServerId = GetPlayerServerId(targetPlayer)
                        if targetServerId and targetServerId > 0 then
                            -- Notify server that this player got hit
                            TriggerServerEvent('arena:server:PlayerGotHit', targetServerId)
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

-- ===================================================================
-- Weapon Shop NPC
-- ===================================================================

local function CreateShopPed()
    if shopPed and DoesEntityExist(shopPed) then return end

    local model = Config.WeaponShop.pedModel
    local coords = Config.WeaponShop.coords

    print('[Arena Zone] Creating shop ped: ' .. model .. ' at ' .. tostring(coords))

    if not LoadModel(model) then
        print('[Arena Zone] FAILED to load model: ' .. model)
        return
    end

    shopPed = CreatePed(4, GetHashKey(model), coords.x, coords.y, coords.z - 1.0, coords.w, false, true)

    if not shopPed or not DoesEntityExist(shopPed) then
        print('[Arena Zone] FAILED to create ped!')
        return
    end

    SetEntityAsMissionEntity(shopPed, true, true)
    SetBlockingOfNonTemporaryEvents(shopPed, true)
    SetPedDiesWhenInjured(shopPed, false)
    SetEntityInvincible(shopPed, true)
    FreezeEntityPosition(shopPed, true)
    SetPedFleeAttributes(shopPed, 0, false)
    SetPedCombatAttributes(shopPed, 46, true)
    SetPedCanRagdollFromPlayerImpact(shopPed, false)

    print('[Arena Zone] Shop ped created successfully! Entity: ' .. tostring(shopPed))

    -- qb-target
    if GetResourceState('qb-target') == 'started' then
        exports['qb-target']:AddTargetEntity(shopPed, {
            options = {
                {
                    type = 'client',
                    event = 'arena:client:OpenShop',
                    icon = 'fas fa-gun',
                    label = 'Buy Rubber Weapon',
                },
            },
            distance = 2.5,
        })
        print('[Arena Zone] qb-target added to ped')
    elseif GetResourceState('ox_target') == 'started' then
        exports.ox_target:addLocalEntity(shopPed, {
            {
                name = 'arena_buy_weapon',
                icon = 'fas fa-gun',
                label = 'Buy Rubber Weapon',
                onSelect = function()
                    TriggerEvent('arena:client:OpenShop')
                end,
                distance = 2.5,
            },
        })
        print('[Arena Zone] ox_target added to ped')
    end
end

local function DeleteShopPed()
    if shopPed and DoesEntityExist(shopPed) then
        if GetResourceState('qb-target') == 'started' then
            exports['qb-target']:RemoveTargetEntity(shopPed)
        end
        DeleteEntity(shopPed)
        shopPed = nil
        print('[Arena Zone] Shop ped deleted')
    end
end

-- ===================================================================
-- Weapon Management
-- ===================================================================

local function GiveArenaWeapon()
    local ped = PlayerPedId()
    local weaponHash = GetHashKey(Config.WeaponShop.weapon)
    GiveWeaponToPed(ped, weaponHash, Config.WeaponShop.ammo, false, true)
    SetCurrentPedWeapon(ped, weaponHash, true)
    hasArenaWeapon = true
end

local function RemoveArenaWeapon()
    if not hasArenaWeapon then return end
    local ped = PlayerPedId()
    local weaponHash = GetHashKey(Config.WeaponShop.weapon)
    RemoveWeaponFromPed(ped, weaponHash)
    hasArenaWeapon = false
    QBCore.Functions.Notify('Weapon removed - you left the zone', 'error', 3000)
end

-- ===================================================================
-- Events
-- ===================================================================

RegisterNetEvent('arena:client:UpdateEventStage', function(stage)
    currentEventStage = stage
    -- If event stage is 2 and player is in zone = spawn ped
    if stage == Config.RequiredEventStage and isInArenaZone then
        CreateShopPed()
    end
    -- If event stage changed from 2 = delete ped
    if stage ~= Config.RequiredEventStage then
        DeleteShopPed()
    end
end)

RegisterNetEvent('arena:client:OpenShop', function()
    if currentEventStage ~= Config.RequiredEventStage then
        QBCore.Functions.Notify('Shop is closed! Admin must type /event 2', 'error', 3000)
        return
    end
    if hasArenaWeapon then
        QBCore.Functions.Notify('You already have the weapon!', 'error', 3000)
        return
    end
    TriggerServerEvent('arena:server:BuyWeapon')
end)

RegisterNetEvent('arena:client:GiveWeapon', function()
    GiveArenaWeapon()
end)

-- ===================================================================
-- Auto Respawn System
-- ===================================================================

local function HandleArenaRespawn()
    if isRespawning then return end
    isRespawning = true

    -- Reset hit counter
    hitCount = 0

    local point = GetRandomRespawnPoint()

    -- Wait before respawn
    QBCore.Functions.Notify('Respawning in ' .. Config.DeathWaitTime .. ' seconds...', 'primary', Config.DeathWaitTime * 1000)
    Wait(Config.DeathWaitTime * 1000)

    -- Server-side respawn
    TriggerServerEvent('arena:server:RespawnPlayer')
    Wait(1000)

    -- Teleport to respawn point
    local ped = PlayerPedId()
    SetEntityCoordsNoOffset(ped, point.x, point.y, point.z, false, false, false)
    SetEntityHeading(ped, point.w)
    NetworkResurrectLocalPlayer(point.x, point.y, point.z, point.w, true, false)

    -- Wait then heal
    Wait(Config.RespawnHealDelay * 1000)

    ped = PlayerPedId()
    SetEntityHealth(ped, GetEntityMaxHealth(ped))
    SetPedArmour(ped, 0)
    ClearPedBloodDamage(ped)
    ClearPedTasksImmediately(ped)
    SetEntityInvincible(ped, false)

    -- Return weapon only if inside weapon zone
    if hasArenaWeapon and IsPlayerInWeaponZone() then
        Wait(500)
        GiveArenaWeapon()
    else
        -- Outside weapon zone, don't return weapon
        hasArenaWeapon = false
    end

    QBCore.Functions.Notify('Respawned! Get ready', 'success', 3000)
    isRespawning = false
end

-- ===================================================================
-- Main Threads
-- ===================================================================

-- Monitor zone entry/exit + death
CreateThread(function()
    while true do
        local sleep = 500
        local wasInArena = isInArenaZone
        isInArenaZone = IsPlayerInArena()

        -- Entered zone
        if isInArenaZone and not wasInArena then
            QBCore.Functions.Notify('You entered the Arena Zone', 'primary', 3000)
            if currentEventStage == Config.RequiredEventStage then
                CreateShopPed()
            end
        end

        -- Left zone
        if not isInArenaZone and wasInArena then
            if hasArenaWeapon then
                RemoveArenaWeapon()
            end
        end

        -- Monitor death inside zone
        if isInArenaZone and not isRespawning then
            local ped = PlayerPedId()
            local playerData = QBCore.Functions.GetPlayerData()
            local isDead = IsEntityDead(ped)
            local isDeadMeta = playerData and playerData.metadata and playerData.metadata['isdead']
            local isLaststand = playerData and playerData.metadata and playerData.metadata['inlaststand']

            if isDead or isDeadMeta or isLaststand then
                -- Notify server that player died (for death sounds)
                TriggerServerEvent('arena:server:PlayerDied')
                HandleArenaRespawn()
            end
        end

        Wait(sleep)
    end
end)

-- Monitor weapon zone removal (leaving zone removes weapon)
CreateThread(function()
    local wasInWeaponZone = false
    while true do
        local sleep = 1000
        if hasArenaWeapon then
            sleep = 300
            local inArena = IsPlayerInArena()
            local inWeaponZone = IsPlayerInWeaponZone()

            -- If left arena or weapon zone = remove weapon
            if not inArena or (wasInWeaponZone and not inWeaponZone) then
                RemoveArenaWeapon()
            end
            wasInWeaponZone = inWeaponZone
        else
            wasInWeaponZone = IsPlayerInWeaponZone()
        end
        Wait(sleep)
    end
end)

-- Ensure ped exists while player is in zone and event is active
CreateThread(function()
    while true do
        Wait(5000)
        if isInArenaZone and currentEventStage == Config.RequiredEventStage then
            if not shopPed or not DoesEntityExist(shopPed) then
                shopPed = nil
                CreateShopPed()
            end
        end
    end
end)

-- ===================================================================
-- Initialization
-- ===================================================================

CreateThread(function()
    Wait(2000)
    TriggerServerEvent('arena:server:GetEventStage')
    if IsPlayerInArena() then
        isInArenaZone = true
    end
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    Wait(3000)
    TriggerServerEvent('arena:server:GetEventStage')
    if IsPlayerInArena() then
        isInArenaZone = true
    end
end)

-- Cleanup
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    DeleteShopPed()
    if hasArenaWeapon then
        RemoveWeaponFromPed(PlayerPedId(), GetHashKey(Config.WeaponShop.weapon))
    end
end)

-- ===================================================================
-- Test Sound Command (remove after testing)
-- /testsound youcane | focus | youkill | noob | all
-- ===================================================================
RegisterCommand('testsound', function(source, args)
    local soundName = args[1] or 'all'
    
    if soundName == 'all' then
        QBCore.Functions.Notify('Playing: YOU CANE...', 'primary', 1500)
        PlayArenaSound('youcane', 0.8)
        Wait(2000)
        QBCore.Functions.Notify('Playing: FOCUS...', 'primary', 1500)
        PlayArenaSound('focus', 0.8)
        Wait(2000)
        QBCore.Functions.Notify('Playing: YOU KILL + NOOB...', 'primary', 1500)
        PlayDeathSounds(0.8)
    elseif soundName == 'death' then
        PlayDeathSounds(0.8)
    else
        QBCore.Functions.Notify('Playing: ' .. soundName, 'primary', 1500)
        PlayArenaSound(soundName, 0.8)
    end
end, false)
