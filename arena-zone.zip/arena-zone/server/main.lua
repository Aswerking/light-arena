local QBCore = exports['qb-core']:GetCoreObject()

local eventStage = 0

-- ===== Admin Command =====
QBCore.Commands.Add('event', 'Set event stage (Admin)', { { name = 'stage', help = 'Event stage number' } }, false, function(source, args)
    local stage = tonumber(args[1])
    if stage then
        eventStage = stage
        TriggerClientEvent('arena:client:UpdateEventStage', -1, eventStage)
        TriggerClientEvent('QBCore:Notify', source, 'Event stage set to: ' .. stage, 'success')
        print('[Arena Zone] Event stage set to: ' .. stage .. ' by ' .. GetPlayerName(source))
    else
        TriggerClientEvent('QBCore:Notify', source, 'Usage: /event [number]', 'error')
    end
end, 'admin')

-- ===== Get Event Stage =====
RegisterNetEvent('arena:server:GetEventStage', function()
    local src = source
    TriggerClientEvent('arena:client:UpdateEventStage', src, eventStage)
end)

-- ===== Buy Weapon =====
RegisterNetEvent('arena:server:BuyWeapon', function()
    local src = source
    if eventStage ~= Config.RequiredEventStage then
        TriggerClientEvent('QBCore:Notify', src, 'Event is not active!', 'error')
        return
    end
    TriggerClientEvent('arena:client:GiveWeapon', src)
    TriggerClientEvent('QBCore:Notify', src, 'You received ' .. Config.WeaponShop.label .. ' - ' .. Config.WeaponShop.ammo .. ' rounds', 'success')
end)

-- ===== Respawn Player =====
RegisterNetEvent('arena:server:RespawnPlayer', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    Player.Functions.SetMetaData('isdead', false)
    Player.Functions.SetMetaData('inlaststand', false)

    TriggerClientEvent('hospital:client:Revive', src)
end)

-- ===== Hit Tracking =====
local playerHitCounts = {} -- Hit counter per player

RegisterNetEvent('arena:server:PlayerGotHit', function(targetServerId)
    local src = source -- The shooter
    
    -- Make sure victim exists
    local targetPlayer = QBCore.Functions.GetPlayer(targetServerId)
    if not targetPlayer then return end

    -- Increment hit counter for victim
    if not playerHitCounts[targetServerId] then
        playerHitCounts[targetServerId] = 0
    end
    playerHitCounts[targetServerId] = playerHitCounts[targetServerId] + 1

    local hits = playerHitCounts[targetServerId]

    -- Send sound to victim
    TriggerClientEvent('arena:client:GotHit', targetServerId, hits)
end)

-- When player dies in arena
RegisterNetEvent('arena:server:PlayerDied', function()
    local src = source

    -- Play death sounds for victim
    TriggerClientEvent('arena:client:GotKilled', src)

    -- Reset hit counter
    playerHitCounts[src] = 0
end)

-- Cleanup when player disconnects
AddEventHandler('playerDropped', function()
    local src = source
    playerHitCounts[src] = nil
end)
